import React, { Component } from 'react';
import { StyleSheet, Button, View, Text } from 'react-native';


class ButtonComponent extends Component {
  constructor(props) {
    super(props);
  }

  render() {
    return (
      <Text>自定义按钮 未启用</Text>
    );
  }
}



export default ButtonComponent;

