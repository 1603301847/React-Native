module.exports = {
    // origin:"http://server.wis-longyun.com/",   // 服务器地址
    origin:"http://wis-longyun.com/server/",   // 服务器地址


    // origin:"http://182.168.1.132:9900/",   // 服务器地址
    // origin:"http://10.6.12.161:9900/",   // 服务器地址

};